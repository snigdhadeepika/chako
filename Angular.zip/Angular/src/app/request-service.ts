import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Requests } from './requests';
import { Types } from './types';
import { Observable } from 'rxjs';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  @Injectable({
    providedIn: 'root'
  })

  export class RequestServiceService{
    id:number=0;
 
    private addNewRequestURL= 'http://localhost:9090/api/passrequests/new';
    private getPendingRequestUrl= 'http://localhost:9090/api/passrequests/location/Pune';
    private getTypesURL = 'http://localhost:9090/api/visitortypes';
    private getRequestByIdURL= 'http://localhost:9090/api/passrequests';
    private getRequestsByEmployeeURL='http://localhost:9090/api/passrequests/employee';
    private approveRejectURL= 'http://localhost:9090/api/passrequests/approvereject';


    constructor(private http:HttpClient) { }

    public getTypes(){
      return this.http.get<Types[]>(this.getTypesURL);
    }
    
    public addNewRequest(request: Requests, file: File):Observable<Object> {
      const formData= new FormData();
      formData.append('file', file, file.name); 
      Object.keys(request).forEach(key => {
        let value = request[key];
        if (typeof value === 'number' || value instanceof Date) {
            value = value.toString();
        }
        formData.append(key, value);
      });
      return this.http.post(`${this.addNewRequestURL}`, formData, { responseType: 'text' as 'json'});
    }

    public getPendingRequest(): Observable<Requests[]> {
       return this.http.get<Requests[]>(`${this.getPendingRequestUrl}`);
      }
    
    public getRequestById(id: number):Observable<Requests>{
      return this.http.get<Requests>(`${this.getRequestByIdURL}/${id}`);
    }

    public getRequestsByEmployee(empid: string):Observable<Requests[]>{
      return this.http.get<Requests[]>(`${this.getRequestsByEmployeeURL}/${empid}`);
    }

    public approveReject(request: Requests): Observable<Object>{
      return this.http.post(`${this.approveRejectURL}`,request)
    }
    public getId(){
        return this.id;
    }

  }