import { Component , OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonClickService } from '../button-click.service';
import { RequestServiceService } from '../request-service';
import { Requests } from '../requests';

@Component({
  selector: 'app-approve-reject-request',
  templateUrl: './approve-reject-request.component.html',
  styleUrls: ['./approve-reject-request.component.css']
})
export class ApproveRejectRequestComponent implements OnInit{
  request: Requests= new Requests();
  id!:number;
  submitted= false;
  isApproved!: boolean;

  constructor(private requestService: RequestServiceService, private router: Router, private route: ActivatedRoute, private buttonClick: ButtonClickService) {
  
    this.buttonClick.currentStatus.subscribe(status => {
      this.isApproved = status === 'approved';
    });
  }

  ngOnInit(): void {
    this.id= this.route.snapshot.params['id'];
    this.requestService.getRequestById(this.id).subscribe(data =>{
    this.request= data;
    }, error=>console.log(error));
  }
  onSubmit() {
    this.requestService.approveReject(this.request).subscribe(data =>{
      this.goToRequestList();
    }, error => console.error(error));
    
  }

  goToRequestList(){
    this.router.navigate(['/pass-requests']);
  }
}
