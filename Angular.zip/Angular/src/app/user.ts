export class User {
    userName!: number;
    password!: string;
    role!: string;
    employeeId!: string;
    isAccountLocked!:boolean;
}
