import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RequestServiceService } from '../request-service';
import { Requests } from '../requests';
import { Types } from '../types';
import { EmployeeIdService } from '../employee-id-service';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-new-pass-request',
  templateUrl: './new-pass-request.component.html',
  styleUrls: ['./new-pass-request.component.css']
})
export class NewPassRequestComponent implements OnInit {

  request: Requests = new Requests();
  types: Types[] = [];
  submitted = false;
  file!: File;
  today: string;
  id:string='';
  incorrectId: boolean = false;

  constructor(private requestService: RequestServiceService, private employeeIdService: EmployeeIdService, private router: Router) {
    this.today = formatDate(new Date(), 'yyyy-MM-dd', 'en-US');
    this.id = sessionStorage.getItem('employeeid') || '';

  }

  ngOnInit() {
    this.fetchTypes();
  }

  save() {
    this.requestService.addNewRequest(this.request, this.file).subscribe({
      next: (data) => {
        console.log(data);
        let notificationBar = document.getElementById('notification-bar');
        if (notificationBar !== null) {
        notificationBar.innerHTML = `<div class="alert alert-success" role="alert">success</div>`;
          this.goToRequestList();
      }
      if(notificationBar?.innerHTML=="success"){
         this.goToRequestList();
      }
      },
      error: err => {
        let notificationBar = document.getElementById('notification-bar');
        if (notificationBar !== null) {
          let errorMessage = err.error;
          notificationBar.innerHTML = `<div class="alert alert-danger" role="alert">${errorMessage}</div>`;
          setTimeout(() => {
            if (notificationBar !== null) {
              notificationBar.innerHTML = '';
            }
          }, 10000);
        }

      }
    });
    this.scrollToTop();
  }


  onChangeFile(event: any) {
    this.file = event.target.files[0];
    const maxSize = 500 * 1024;
    const fileSizeError = document.getElementById('fileSizeError');
    if (this.file.size > maxSize) {
        if (fileSizeError) {
            fileSizeError.innerText = 'File size should not exceed 500KB';
        }
    } else {
        if (fileSizeError) {
            fileSizeError.innerText = '';
        }
    }
  }

  onSubmit() {
    this.employeeIdService.changeEmployee(this.request.raisedByEmployee);
    console.log(this.request);
    console.log(this.file);
    console.log(this.id);
    if (!this.request.purposeOfVisit || !this.request.location || !this.request.visitorName || !this.request.comingFrom || !this.request.idProofNo) {
      this.scrollToTop();
      console.log('Please fill out all fields before submitting.');
      alert('Please fill out all fields before submitting.');

      return; 
  }
    if (this.request.raisedByEmployee !== this.id) {
      this.incorrectId = true;
      this.scrollToTop();
    } else {
      this.incorrectId = false;
      this.save();

    }
    
  }
  goToHome() {
    this.router.navigate(['/home']);
  }

  goToRequestList() {
    this.router.navigate(['/pass-requests']);
  }

  fetchTypes() {
    this.requestService.getTypes()
      .subscribe(responseData => {
        this.types = responseData;
      })
  }

  scrollToTop() {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    })
  }

  validateAge(ageControl: any) {
    if (ageControl.value < 0) {
        ageControl.setErrors({'invalid': true});
    }
}
}
