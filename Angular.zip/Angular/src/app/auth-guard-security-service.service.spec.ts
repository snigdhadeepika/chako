import { TestBed } from '@angular/core/testing';

import { AuthGuardSecurityServiceService } from './auth-guard-security-service.service';

describe('AuthGuardSecurityServiceService', () => {
  let service: AuthGuardSecurityServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthGuardSecurityServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
