import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ButtonClickService {
  private requestStatus = new BehaviorSubject<string | null>(null);
  currentStatus = this.requestStatus.asObservable();

  constructor() { }

  changeStatus(status: string) {
    this.requestStatus.next(status);
  }
}
