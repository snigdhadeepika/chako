import { EmployeeIdService } from './employee-id-service';

describe('EmployeeIdService', () => {
  it('should create an instance', () => {
    expect(new EmployeeIdService()).toBeTruthy();
  });
});
