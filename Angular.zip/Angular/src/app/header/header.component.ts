import { Component , OnInit} from '@angular/core';
import { AuthenticationService } from '../authentication-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  role:string='';
  id:string='';
  loggedin:boolean=false;

  constructor(private authService: AuthenticationService,private router:Router){
    this.role = sessionStorage.getItem('role') || '';
    this.id = sessionStorage.getItem('employeeid') || '';
    this.loggedin=authService.isUserLoggedIn();
    console.log(this.role);
    console.log(this.id);
    console.log(this.loggedin);
  }

  logOut(){
    console.log(this.role);
    this.authService.logOut();
    this.router.navigate(['/login']);
  }

}
