import { Component } from '@angular/core';
import { Requests } from '../requests';
import { ActivatedRoute } from '@angular/router';
import { RequestServiceService } from '../request-service';
import { Router } from '@angular/router';
import { ButtonClickService } from '../button-click.service';
@Component({
  selector: 'app-pass-request-details',
  templateUrl: './pass-request-details.component.html',
  styleUrls: ['./pass-request-details.component.css']
})
export class PassRequestDetailsComponent {
  id!: number;
  request!: Requests;
  constructor( private router: Router, private route: ActivatedRoute, private requestService: RequestServiceService, private buttonClick: ButtonClickService){

  }
  ngOnInit(){
    this.id= this.route.snapshot.params['id'];
    this.request= new Requests();
    this.requestService.getRequestById(this.id).subscribe(data =>{
      this.request= data;
    });
  }
  rejectRequest(id: number){
    this.buttonClick.changeStatus('rejected');
    this.router.navigate(['reject-request', id]);
  }
  approveRequest(id: number){
    this.buttonClick.changeStatus('approved');
    this.router.navigate(['approve-request', id]);
  }
}
