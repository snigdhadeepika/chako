import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PassRequestDetailsComponent } from './pass-request-details.component';

describe('PassRequestDetailsComponent', () => {
  let component: PassRequestDetailsComponent;
  let fixture: ComponentFixture<PassRequestDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PassRequestDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PassRequestDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
