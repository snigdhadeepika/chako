import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeIdService {
  private employeeSource = new BehaviorSubject<string>('');
  currentEmployee = this.employeeSource.asObservable();

  constructor() { }

  changeEmployee(employeeId: string) {
    this.employeeSource.next(employeeId);
  }
}
