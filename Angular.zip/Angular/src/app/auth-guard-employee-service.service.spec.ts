import { TestBed } from '@angular/core/testing';

import { AuthGuardEmployeeServiceService } from './auth-guard-employee-service.service';

describe('AuthGuardEmployeeServiceService', () => {
  let service: AuthGuardEmployeeServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthGuardEmployeeServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
