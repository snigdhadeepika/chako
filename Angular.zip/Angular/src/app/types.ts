export class Types {
    id: number=0;
    type: string="";
}
