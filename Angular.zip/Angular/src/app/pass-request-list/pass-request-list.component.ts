import { Component , OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { Requests } from '../requests';
import { RequestServiceService } from '../request-service';
import { ActivatedRoute } from '@angular/router';
import { EmployeeIdService } from '../employee-id-service';
import { AuthenticationService } from '../authentication-service';

@Component({
  selector: 'app-pass-request-list',
  templateUrl: './pass-request-list.component.html',
  styleUrls: ['./pass-request-list.component.css']
})
export class PassRequestListComponent implements OnInit {

 passRequests!: Requests[];
 role:string='';
 empid:string='';
 loggedin:boolean=false;


 

  constructor( private authService: AuthenticationService, private router: Router, private employeeIdService: EmployeeIdService, private requestService: RequestServiceService){
    this.role = sessionStorage.getItem('role') || '';
    this.empid = sessionStorage.getItem('employeeid') || '';
    this.loggedin=authService.isUserLoggedIn();
    console.log(this.role);
    console.log(this.loggedin);

  }
  ngOnInit(): void {
    if (this.role === 'employee') {
      this.getRequestsByEmployee();
    } else if (this.role === 'security') {
      this.getRequest();
    }

  };
  private getRequest(){
    this.requestService.getPendingRequest().subscribe(data => {
      this.passRequests= data;
    });
  }

  private getRequestsByEmployee(){

    this.requestService.getRequestsByEmployee(this.empid).subscribe(data => {
      console.log(data);
      this.passRequests= data;

    });
  }


  viewDetails(id: number){
    this.router.navigate(['request-details', id]);
  }

}
