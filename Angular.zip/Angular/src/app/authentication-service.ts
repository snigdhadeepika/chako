import { HttpClient } from "@angular/common/http";
import { User } from "./user";
import { Injectable } from "@angular/core";
import { first, Observable } from "rxjs";

@Injectable({
    providedIn: 'root'
  })

export class AuthenticationService {
  constructor(private http:HttpClient) { }

  private authenticationURL:string="http://localhost:9090/authenticate/users";

  user!: User;
  userBackend!: User;
  authenticated!:boolean;

  
authenticate(username: any, password: any): Observable<boolean> {
    this.user = new User();
    console.log(username);
    console.log(password);
    this.user.userName = username;
    this.user.password = password;

  return new Observable<boolean>((observer) => {
        this.getUser(this.user).pipe(first()).subscribe((data) => {
            console.log(data);
            this.userBackend = new User();
            this.userBackend.userName = data.userName;
            this.userBackend.password = data.password;
            this.userBackend.role = data.role;
            this.userBackend.employeeId= data.employeeId;
            if (this.user.userName === this.userBackend.userName && this.user.password == this.userBackend.password) {
                this.authenticated = true;
                sessionStorage.setItem('username', username);
                sessionStorage.setItem('role', this.userBackend.role);
                sessionStorage.setItem('employeeid',this.userBackend.employeeId);
            } else {
                this.authenticated = false;
            }
            observer.next(this.authenticated);
            observer.complete();
        });
    });
}


getUser(user: any){
    return this.http.post<User>(this.authenticationURL, user);
}

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    let role=sessionStorage.getItem('role');
    let employeeid=sessionStorage.getItem('employeeid');
    console.log(!(user === null))
    return !(user === null && role===null);

  }

  isUserEmployee(){
    let role=sessionStorage.getItem('role');
    return (role==='employee');
  }

  isUserSecurity(){
    let role=sessionStorage.getItem('role');
    return (role==='security');
  }

  
  logOut() {
    sessionStorage.removeItem('username')
    sessionStorage.removeItem('role');
  }
}

