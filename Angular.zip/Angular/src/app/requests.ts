export class Requests {
    [key: string]: number | string | Date;
    id!: number;
    raisedByEmployee!: string;
    requestRaisedOn!: Date;
    visitorTypeId!: number;
    purposeOfVisit!: string;
    requestStatus!: string;
    requestProcessedByEmployee!: string;
    requestProcessedOn!: Date;
    visitDate!: Date;
    cancellationReason!: string;
    location!: string;
    visitorName!: string;
    visitorAge!: number;
    comingFrom!: string;
    idProofType!: string;
    idProofNo!: string;
    idProofUrl!: string;

}
