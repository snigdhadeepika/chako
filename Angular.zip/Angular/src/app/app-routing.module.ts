import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NewPassRequestComponent } from './new-pass-request/new-pass-request.component';
import { PassRequestListComponent } from './pass-request-list/pass-request-list.component';
import { PassRequestDetailsComponent } from './pass-request-details/pass-request-details.component';
import { ApproveRejectRequestComponent } from './approve-reject-request/approve-reject-request.component';
import { LoginComponent } from './login/login.component';
import { AuthGuardEmployeeServiceService } from './auth-guard-employee-service.service';
import { AuthGuardSecurityServiceService } from './auth-guard-security-service.service';
const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'pass-requests', component: PassRequestListComponent},
  { path: 'login', component: LoginComponent},
  { path: 'new-pass-request', component: NewPassRequestComponent, canActivate:[AuthGuardEmployeeServiceService]},
  { path: 'request-details/:id' , component: PassRequestDetailsComponent},
  { path: 'approve-request/:id' , component: ApproveRejectRequestComponent},
  { path: 'reject-request/:id' , component: ApproveRejectRequestComponent},
  { path: '', redirectTo: 'login', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
