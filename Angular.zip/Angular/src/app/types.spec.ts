import { Types } from './types';

describe('Types', () => {
  it('should create an instance', () => {
    expect(new Types()).toBeTruthy();
  });
});
