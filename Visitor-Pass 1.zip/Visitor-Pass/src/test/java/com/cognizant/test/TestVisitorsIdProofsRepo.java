package com.cognizant.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Optional;

import com.cognizant.dto.VisitorPassRequestsDto;
import com.cognizant.entities.IdProofType;
import com.cognizant.entities.RequestStatus;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.VisitorPassModuleApplication;
import com.cognizant.entities.VisitorPassRequests;
import com.cognizant.entities.VisitorsIdProofs;
import com.cognizant.repositories.VisitorIdProofsRepo;
import com.cognizant.repositories.VisitorPassRequestsRepo;

@DataJpaTest
@ContextConfiguration(classes = VisitorPassModuleApplication.class)
class TestVisitorIdProofsRepo {
    @Autowired
    private VisitorIdProofsRepo visitorIdProofsRepo;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindAllPositive() {
        VisitorPassRequests visitorPassRequests=new VisitorPassRequests();
        visitorPassRequests.setRaisedByEmployee("Sony");
        visitorPassRequests.setRequestRaisedOn(LocalDate.now());
        visitorPassRequests.setPurposeOfVisit("Client Visit");
        visitorPassRequests.setRequestStatus(RequestStatus.APPROVED);
        visitorPassRequests.setRequestProcessedByEmployee("Yes");
        visitorPassRequests.setRequestProcessedOn(LocalDate.now());
        visitorPassRequests.setVisitDate(LocalDate.now());
        visitorPassRequests.setCancellationReason("meeting");
        visitorPassRequests.setLocation("CDC Pune");
        visitorPassRequests.setVisitorName("Chacko");
        visitorPassRequests.setVisitorAge(50);
        visitorPassRequests.setComingFrom("Kerala");
        visitorPassRequests.setVisitorTypes(null);
        entityManager.persist(visitorPassRequests);
        entityManager.flush();
        VisitorsIdProofs v=new VisitorsIdProofs();
        v.setRequestId(visitorPassRequests.getId());
        v.setIdProofType(IdProofType.VOTERID);
        v.setIdProofNo("V100");
        v.setIdProofUrl("http://id/url");
        entityManager.merge(v); // Changed from persist to merge
        entityManager.flush();
        Iterable<VisitorsIdProofs> it=visitorIdProofsRepo.findAll();
        assertTrue(it.iterator().hasNext());
    }


    @Test
    public void testFindAllNegative() {
        Iterable<VisitorsIdProofs> it=visitorIdProofsRepo.findAll();
        assertTrue(!it.iterator().hasNext());
    }


    @Test
    public void testFindByIdNegative() {
        VisitorPassRequests visitorPassRequests=new VisitorPassRequests();
        Optional<VisitorsIdProofs> visitorIdProofs=visitorIdProofsRepo.findById(visitorPassRequests.getId());
        assertTrue(!visitorIdProofs.isPresent());
    }

    @Test
    public void testSavePositive() {
        VisitorPassRequests visitorPassRequests=new VisitorPassRequests();
        VisitorsIdProofs v=new VisitorsIdProofs();
        v.setRequestId(visitorPassRequests.getId());
        v.setIdProofType(IdProofType.VOTERID);
        v.setIdProofNo("V100");
        v.setIdProofUrl("http://id/url");
        visitorIdProofsRepo.save(v);
        Optional<VisitorsIdProofs> visitorIdProofs=visitorIdProofsRepo.findById(v.getRequestId());
        assertTrue(visitorIdProofs.isPresent());
    }

    @Test
    public void testDeletePositive() {
        VisitorPassRequests visitorPassRequests=new VisitorPassRequests();
        VisitorsIdProofs v=new VisitorsIdProofs();
        v.setRequestId(visitorPassRequests.getId());
        v.setIdProofType(IdProofType.VOTERID);
        v.setIdProofNo("V100");
        v.setIdProofUrl("http://id/url");
        entityManager.persist(v);
        visitorIdProofsRepo.delete(v);
        Optional<VisitorsIdProofs> visitorIdProofs=visitorIdProofsRepo.findById(v.getRequestId());
        assertTrue(!visitorIdProofs.isPresent());
    }

    @Test
    public void testCountPositive() {
        VisitorPassRequests visitorPassRequests=new VisitorPassRequests();
        entityManager.persist(visitorPassRequests);
        VisitorsIdProofs v= new VisitorsIdProofs();
        v.setRequestId(visitorPassRequests.getId());
        v.setIdProofType(IdProofType.VOTERID);
        v.setIdProofNo("V100");
        v.setIdProofUrl("http://localhost/url");
        entityManager.merge(v);
        long expectedCount=1;
        long actualCount=visitorIdProofsRepo.count();
        assertEquals(expectedCount, actualCount);
    }

}
