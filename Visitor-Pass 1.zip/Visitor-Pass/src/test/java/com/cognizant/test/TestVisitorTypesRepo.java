package com.cognizant.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.VisitorPassModuleApplication;
import com.cognizant.entities.VisitorTypes;
import com.cognizant.repositories.VisitorTypesRepo;

@DataJpaTest
@ContextConfiguration(classes = VisitorPassModuleApplication.class)
class TestVisitorTypesRepo {
	@Autowired
	private VisitorTypesRepo visitorTypesRepo;
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void testFindAllPositive() {
		VisitorTypes v=new VisitorTypes();
		v.setId(100);
		v.setType("Client");
		entityManager.persist(v);
		Iterable<VisitorTypes> it=visitorTypesRepo.findAll();
		assertTrue(it.iterator().hasNext());
	}
	
	@Test
	public void testFindAllNegative() {
		Iterable<VisitorTypes> it=visitorTypesRepo.findAll();
		assertTrue(it.iterator().hasNext());
	}
	
	@Test
	public void testFindByIdPositive() {
		VisitorTypes v=new VisitorTypes();
		v.setId(100);
		v.setType("Client");
		entityManager.persist(v);
		Optional<VisitorTypes> visitorTypes=visitorTypesRepo.findById(100);
		assertTrue(visitorTypes.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<VisitorTypes> visitorTypes=visitorTypesRepo.findById(100);
		assertTrue(!visitorTypes.isPresent());
	}
	
	@Test
	public void testSavePositive() {
		VisitorTypes v=new VisitorTypes();
		v.setId(100);
		v.setType("Client");
		visitorTypesRepo.save(v);
		Optional<VisitorTypes> visitorTypes=visitorTypesRepo.findById(100);
		assertTrue(visitorTypes.isPresent());
	}
	
	@Test
	public void testDeletePositive() {
		VisitorTypes v=new VisitorTypes();
		v.setId(100);
		v.setType("Client");
		entityManager.persist(v);
		visitorTypesRepo.delete(v);
		Optional<VisitorTypes> visitorTypes=visitorTypesRepo.findById(100);
		assertTrue(!visitorTypes.isPresent());
	}
	
	@Test
	public void testCountPositive() {
		VisitorTypes v=new VisitorTypes();
		v.setId(100);
		v.setType("Client");
		entityManager.persist(v);
		long expectedCount=6;
		long actualCount=visitorTypesRepo.count();
		assertEquals(expectedCount, actualCount);
	}
}
