package com.cognizant.test;

import com.cognizant.dto.VisitorTypesDto;
import com.cognizant.entities.VisitorTypes;
import com.cognizant.repositories.VisitorTypesRepo;
import com.cognizant.service.VisitorTypesServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;


public class TestVisitorTypesServiceImpl {
    @Mock
    private VisitorTypesRepo visitorTypesRepo;
    @InjectMocks
    private VisitorTypesServiceImpl visitorTypesServiceImpl;

    @BeforeEach
    void setUp() throws Exception{
        MockitoAnnotations.openMocks(this);
    }
    @AfterEach
    void tearDown() throws Exception{

    }
    @Test
    public void testGetAllVisitorTypes_WhenVisitorTypesExist(){
        try {
            List<VisitorTypes> visitorTypesList= List.of(new VisitorTypes(1,"Parents",null),new VisitorTypes(2,"Child",null),new VisitorTypes(3,"Sibling",null),new VisitorTypes(4,"Spouse",null),new VisitorTypes(5,"Client",null));
            when(visitorTypesRepo.findAll()).thenReturn(visitorTypesList);
            List<VisitorTypesDto> resultDtos = visitorTypesServiceImpl.getAllVisitorTypes();
            assertNotNull(resultDtos);
            assertEquals(visitorTypesList.size(), resultDtos.size());

        } catch (Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllVisitorTypes_WhenVisitorTypesNotExist(){
        List<VisitorTypes> emptyList= new ArrayList<>();
        when(visitorTypesRepo.findAll()).thenReturn(emptyList);
        assertThrows(RuntimeException.class,() -> {
            visitorTypesServiceImpl.getAllVisitorTypes();
        });
    }
}
