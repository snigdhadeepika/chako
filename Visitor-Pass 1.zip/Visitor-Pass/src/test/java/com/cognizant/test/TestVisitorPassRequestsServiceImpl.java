package com.cognizant.test;

import com.cognizant.dto.UpdatePassRequestDto;
import com.cognizant.dto.VisitorPassRequestsDto;
import com.cognizant.entities.*;
import com.cognizant.exception.MaximumPassRequestLimitReachedException;
import com.cognizant.repositories.VisitorIdProofsRepo;
import com.cognizant.repositories.VisitorPassRequestsRepo;
import com.cognizant.repositories.VisitorTypesRepo;
import com.cognizant.service.VisitorPassRequestsServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class TestVisitorPassRequestsServiceImpl {
    @Mock
    private VisitorPassRequestsRepo visitorPassRequestsRepo;
    @Mock
    private VisitorTypesRepo visitorTypesRepo;
    @Mock
    private VisitorIdProofsRepo visitorIdProofsRepo;
    @Mock
    private Map<String,Integer> familyRequestCountMapMock;
    private Map<String, Integer> userRequestCountMap;
    @InjectMocks
    private VisitorPassRequestsServiceImpl visitorPassRequestsServiceImpl;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Test
    public void testApproveRejectRequest_Positive() {
        try {
            UpdatePassRequestDto updatePassRequestDto = new UpdatePassRequestDto();
            updatePassRequestDto.setId(100);
            updatePassRequestDto.setRequestStatus(RequestStatus.REJECTED);
            updatePassRequestDto.setCancellationReason("xyz");

            VisitorPassRequests request = new VisitorPassRequests();
            request.setId(100);
            request.setRequestStatus(RequestStatus.APPROVED);
            request.setCancellationReason("Not Applicable");

            when(visitorPassRequestsRepo.findById(100)).thenReturn(Optional.of(request));

            VisitorPassRequests savedRequest = new VisitorPassRequests();
            savedRequest.setId(100);
            savedRequest.setRequestStatus(RequestStatus.REJECTED);
            savedRequest.setCancellationReason("xyz");

            when(visitorPassRequestsRepo.save(request)).thenReturn(savedRequest);
            String result = visitorPassRequestsServiceImpl.approveRejectRequest(updatePassRequestDto);
            assertEquals("success", result);

        } catch (Exception e) {
            assertTrue(false);
        }

    }

    @Test
    public void testApproveRejectRequest_Negative() {
        UpdatePassRequestDto updatePassRequestDto = new UpdatePassRequestDto();
        updatePassRequestDto.setId(1);
        updatePassRequestDto.setRequestStatus(RequestStatus.APPROVED);
        updatePassRequestDto.setCancellationReason("N/A");

        when(visitorPassRequestsRepo.findById(updatePassRequestDto.getId())).thenReturn(Optional.empty());

        String result = visitorPassRequestsServiceImpl.approveRejectRequest(updatePassRequestDto);

        assertEquals("fail", result);
    }

    @Test
    public void testCanRaiseFamilyVisitorRequest_Positive(){
        String raisedByEmployee="Sony";
        int currentMonth= LocalDate.now().getMonthValue();
        int currentYear= LocalDate.now().getYear();
        String key= raisedByEmployee + "-family-" + currentMonth + "-" + currentYear;
        when(familyRequestCountMapMock.getOrDefault(key,0)).thenReturn(1);
        boolean result= visitorPassRequestsServiceImpl.canRaiseFamilyVisitorRequest(raisedByEmployee);
        assertTrue(result);
    }

    @Test
    public void testCanRaiseFamilyVisitorRequest_Negative(){
        String raisedByEmployee="Sony";
        int currentMonth= LocalDate.now().getMonthValue();
        int currentYear= LocalDate.now().getYear();
        String key= raisedByEmployee + "-family-" + currentMonth + "-" + currentYear;
        when(familyRequestCountMapMock.getOrDefault(key,0)).thenReturn(2);
        boolean result= visitorPassRequestsServiceImpl.canRaiseFamilyVisitorRequest(raisedByEmployee);
        assertFalse(result);
    }

    @Test
    public void testRaiseFamilyVisitorRequest(){
        String raisedByEmployee="Sony";
        int currentMonth= LocalDate.now().getMonthValue();
        int currentYear= LocalDate.now().getYear();
        String expectedKey= raisedByEmployee + "-family-" + currentMonth + "-" + currentYear;
        int expectedCount=1;
        when(familyRequestCountMapMock.getOrDefault(expectedKey,0)).thenReturn(0);
        visitorPassRequestsServiceImpl.raiseFamilyVisitorRequest(raisedByEmployee);
        verify(familyRequestCountMapMock).put(eq(expectedKey),eq(expectedCount));
    }

    @Test
    public void testGetRequestById_Positive(){
        try{
            int testData=100;
            VisitorTypes visitorTypes= new VisitorTypes();
            visitorTypes.setId(1);
            VisitorPassRequests request= new VisitorPassRequests();
            request.setId(100);
            request.setRaisedByEmployee("Sony");
            request.setRequestRaisedOn(LocalDate.now());
            request.setVisitorTypes(visitorTypes);
            request.setPurposeOfVisit("Client");
            request.setRequestStatus(RequestStatus.APPROVED);
            request.setRequestProcessedByEmployee("Antony");
            request.setRequestProcessedOn(LocalDate.now());
            request.setVisitDate(LocalDate.now());
            request.setCancellationReason("xyz");
            request.setLocation("Pune");
            request.setVisitorName("Chacko");
            request.setVisitorAge(50);
            request.setComingFrom("Kerala");
            when(visitorPassRequestsRepo.findById(testData)).thenReturn(Optional.of(request));

            VisitorsIdProofs idProofs = new VisitorsIdProofs();
            idProofs.setRequestId(testData);
            idProofs.setIdProofNo("100");
            idProofs.setIdProofUrl("url");
            idProofs.setIdProofType(IdProofType.PASSPORT);
            when(visitorIdProofsRepo.findById(testData)).thenReturn(Optional.of(idProofs));
            VisitorPassRequestsDto dto= visitorPassRequestsServiceImpl.getRequestById(testData);

            assertTrue(dto!=null);

        } catch (Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetRequestById_Negative(){
        try{
            int testData=100;
            when(visitorPassRequestsRepo.findById(testData)).thenReturn(Optional.ofNullable(null));
            VisitorPassRequestsDto dto= visitorPassRequestsServiceImpl.getRequestById(testData);
            assertTrue(dto.getId()==0);

        } catch (Exception e) {
            assertTrue(false);
        }
    }





    @Test
    public void testGetPendingRequestByLocation_WhenRequestsNotExist(){
        String location= "testLocation";
        List<VisitorPassRequests> emptyList= new ArrayList<>();
        when(visitorPassRequestsRepo.findByLocation(location)).thenReturn(emptyList);
        List<VisitorPassRequestsDto> result= visitorPassRequestsServiceImpl.getPendingRequestByLocation(location);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testGetRequestsByEmployee_RequestsPresent() {
        String raisedByEmployee = "employee1";
        VisitorTypes visitorTypes= new VisitorTypes();
        visitorTypes.setId(1);
        VisitorPassRequests request1 = new VisitorPassRequests();
        request1.setId(1);
        request1.setVisitorTypes(visitorTypes);
        VisitorPassRequests request2 = new VisitorPassRequests();
        request2.setId(2);
        request2.setVisitorTypes(visitorTypes);
        when(visitorPassRequestsRepo.findByRaisedByEmployee(raisedByEmployee)).thenReturn(Arrays.asList(request1, request2));
        VisitorsIdProofs idProofs1 = new VisitorsIdProofs();
        idProofs1.setRequestId(1); // Assuming this is the id of VisitorPassRequests
        idProofs1.setIdProofNo("100");
        idProofs1.setIdProofUrl("url");
        idProofs1.setIdProofType(IdProofType.PASSPORT);
        VisitorsIdProofs idProofs2 = new VisitorsIdProofs();
        idProofs2.setRequestId(2); // Assuming this is the id of VisitorPassRequests
        idProofs2.setIdProofNo("100");
        idProofs2.setIdProofUrl("url");
        idProofs2.setIdProofType(IdProofType.PASSPORT);
        when(visitorIdProofsRepo.findById(1)).thenReturn(Optional.of(idProofs1));
        when(visitorIdProofsRepo.findById(2)).thenReturn(Optional.of(idProofs2));
        List<VisitorPassRequestsDto> dtos = visitorPassRequestsServiceImpl.getRequestsByEmployee(raisedByEmployee);
        assertEquals(2, dtos.size());
        assertEquals(1, dtos.get(0).getId());
        assertEquals(2, dtos.get(1).getId());
    }

    @Test
    public void testGetRequestsByEmployee_NoRequests() {
        String raisedByEmployee = "employee1";
        when(visitorPassRequestsRepo.findByRaisedByEmployee(raisedByEmployee)).thenReturn(Arrays.asList());
        List<VisitorPassRequestsDto> dtos = visitorPassRequestsServiceImpl.getRequestsByEmployee(raisedByEmployee);
        assertEquals(0, dtos.size());
    }

    @Test
    public void testAddNewVisitRequests() throws IOException {
        String employeeName = "testEmployee";
        MultipartFile file = new MockMultipartFile("file", "hello.txt", "text/plain", "Hello, World!".getBytes());
        VisitorPassRequestsDto visitorPassRequestsDto = new VisitorPassRequestsDto();
        visitorPassRequestsDto.setRaisedByEmployee(employeeName);
        visitorPassRequestsDto.setVisitDate(LocalDate.now().plusWeeks(2)); // set visit date to be more than a week in advance
        visitorPassRequestsDto.setVisitorTypeId(5);
        visitorPassRequestsDto.setIdProofType(IdProofType.PASSPORT);
        visitorPassRequestsDto.setIdProofNo("123456789");

        VisitorTypes visitorTypes = new VisitorTypes();
        visitorTypes.setType("Client");

        when(visitorTypesRepo.findById(anyInt())).thenReturn(Optional.of(visitorTypes));
        when(visitorPassRequestsRepo.save(any(VisitorPassRequests.class))).thenAnswer(i -> i.getArguments()[0]);
        when(visitorIdProofsRepo.save(any(VisitorsIdProofs.class))).thenAnswer(i -> i.getArguments()[0]);

        String result = visitorPassRequestsServiceImpl.addNewVisitRequests(file, visitorPassRequestsDto);

        assertEquals("success", result);
        verify(visitorPassRequestsRepo, times(1)).save(any(VisitorPassRequests.class));
        verify(visitorIdProofsRepo, times(1)).save(any(VisitorsIdProofs.class));
    }

    @Test
    public void testGetPendingRequestByLocation() {
        String location = "testLocation";

        List<VisitorPassRequests> visitorPassRequests = new ArrayList<>();
        VisitorTypes visitorTypes= new VisitorTypes();
        visitorTypes.setId(1);
        VisitorPassRequests v = new VisitorPassRequests();
        v.setRequestStatus(RequestStatus.PENDING);
        v.setVisitorTypes(visitorTypes);
        visitorPassRequests.add(v);

        when(visitorPassRequestsRepo.findByLocation(location)).thenReturn(visitorPassRequests);

        VisitorsIdProofs idProofs = new VisitorsIdProofs();
        when(visitorIdProofsRepo.findById(v.getId())).thenReturn(Optional.of(idProofs));

        List<VisitorPassRequestsDto> result = visitorPassRequestsServiceImpl.getPendingRequestByLocation(location);

        assertEquals(1, result.size());
        assertEquals(v.getId(), result.get(0).getId());
        assertEquals(idProofs.getIdProofType(), result.get(0).getIdProofType());
    }


}


