package com.cognizant.test;

import com.cognizant.controller.AuthenticationController;
import com.cognizant.controller.VisitorPassController;
import com.cognizant.dto.*;
import com.cognizant.entities.IdProofType;
import com.cognizant.service.UserService;
import com.cognizant.service.VisitorPassRequestsService;
import com.cognizant.service.VisitorPassRequestsServiceImpl;
import com.cognizant.service.VisitorTypesService;
import jakarta.validation.ConstraintViolationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.mockito.MockitoAnnotations;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.junit.Assert.assertEquals;


public class TestVisitorPassController {
    @Mock
    VisitorTypesService visitorTypesService;
    @Mock
    VisitorPassRequestsService visitorPassRequestsService;
    @Mock
    private MethodArgumentNotValidException ex;
    @Mock
    private BindingResult bindingResult;
    @Mock
    private MultipartFile file;
    @Mock
    UserService userService;
    @InjectMocks
    AuthenticationController authenticationController;
    @InjectMocks
    VisitorPassController visitorPassController;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testHandleGetAllVisitorTypes_NotEmpty() {
        VisitorTypesDto visitorType1 = new VisitorTypesDto();
        VisitorTypesDto visitorType2 = new VisitorTypesDto();
        List<VisitorTypesDto> visitorTypesList = Arrays.asList(visitorType1, visitorType2);
        when(visitorTypesService.getAllVisitorTypes()).thenReturn(visitorTypesList);
        ResponseEntity<?> result = visitorPassController.handleGetAllVisitorTypes();

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(visitorTypesList, result.getBody());
    }

    @Test
    public void testHandleGetAllVisitorTypes_Empty() {
        when(visitorTypesService.getAllVisitorTypes()).thenReturn(Arrays.asList());
        ResponseEntity<?> result = visitorPassController.handleGetAllVisitorTypes();
        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
    }

    @Test
    public void testHandleGetRequestByIdByPathParam_ValidId() {
        int id = 1;
        VisitorPassRequestsDto dto = new VisitorPassRequestsDto();
        dto.setId(id);
        when(visitorPassRequestsService.getRequestById(id)).thenReturn(dto);
        ResponseEntity<?> result = visitorPassController.handleGetRequestByIdByPathParam(id);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(dto, result.getBody());
    }

    @Test
    public void testHandleGetRequestByIdByPathParam_InvalidId() {
        int id = 0;
        VisitorPassRequestsDto dto = new VisitorPassRequestsDto();
        dto.setId(id);
        when(visitorPassRequestsService.getRequestById(id)).thenReturn(dto);
        ResponseEntity<?> result = visitorPassController.handleGetRequestByIdByPathParam(id);
        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
    }

    @Test
    public void testHandleGetPendingRequestByLocationByPathParam_NotEmpty() {
        String location = "Test Location";
        VisitorPassRequestsDto dto1 = new VisitorPassRequestsDto();
        VisitorPassRequestsDto dto2 = new VisitorPassRequestsDto();
        List<VisitorPassRequestsDto> dtoList = Arrays.asList(dto1, dto2);
        when(visitorPassRequestsService.getPendingRequestByLocation(location)).thenReturn(dtoList);
        ResponseEntity<?> result = visitorPassController.handleGetPendingRequestByLocationByPathParam(location);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(dtoList, result.getBody());
    }

    @Test
    public void testHandleGetPendingRequestByLocationByPathParam_Empty() {
        String location = "Test Location";
        when(visitorPassRequestsService.getPendingRequestByLocation(location)).thenReturn(Arrays.asList());
        ResponseEntity<?> result = visitorPassController.handleGetPendingRequestByLocationByPathParam(location);
        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
    }

    @Test
    public void testHandleApproveRejectRequest_Success() {
        UpdatePassRequestDto updatePassRequestDto = new UpdatePassRequestDto();
        when(visitorPassRequestsService.approveRejectRequest(updatePassRequestDto)).thenReturn("success");
        ResponseEntity<?> response = visitorPassController.handleApproveRejectRequest(updatePassRequestDto);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testHandleApproveRejectRequest_Failure() {
        UpdatePassRequestDto updatePassRequestDto = new UpdatePassRequestDto();
        when(visitorPassRequestsService.approveRejectRequest(updatePassRequestDto)).thenReturn("failure");
        ResponseEntity<?> response = visitorPassController.handleApproveRejectRequest(updatePassRequestDto);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testHandleValidationExceptions_NoErrors() {
        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getAllErrors()).thenReturn(Collections.emptyList());
        ResponseEntity<?> response = visitorPassController.handleValidationExceptions(ex);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(((List<?>) response.getBody()).isEmpty());
    }

    @Test
    public void testHandleValidationExceptions_WithErrors() {
        ObjectError error1 = new ObjectError("object1", "defaultMessage1");
        ObjectError error2 = new ObjectError("object2", "defaultMessage2");

        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getAllErrors()).thenReturn(Arrays.asList(error1, error2));

        ResponseEntity<?> response = visitorPassController.handleValidationExceptions(ex);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        List<String> errors = (List<String>) response.getBody();
        assertEquals(2, errors.size());
        assertTrue(errors.contains("defaultMessage1"));
        assertTrue(errors.contains("defaultMessage2"));
    }
    @Test
    public void testHandleAddNewVisitRequest_Success() throws IOException {
        when(visitorPassRequestsService.addNewVisitRequests(any(MultipartFile.class), any(VisitorPassRequestsDto.class))).thenReturn("success");

        ResponseEntity<?> response = visitorPassController.handleAddNewVisitRequest(file, "employee1", 1, "visit", LocalDate.now(), "location", "visitor", 30, "comingFrom", IdProofType.PASSPORT, "idProofNo");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Request is generated", response.getBody());
    }

    @Test
    public void testHandleAddNewVisitRequest_Failure() throws IOException {
        when(visitorPassRequestsService.addNewVisitRequests(any(MultipartFile.class), any(VisitorPassRequestsDto.class))).thenReturn("failure");

        ResponseEntity<?> response = visitorPassController.handleAddNewVisitRequest(file, "employee1", 1, "visit", LocalDate.now(), "location", "visitor", 30, "comingFrom", IdProofType.PASSPORT, "idProofNo");

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("User can only add two request for family members in a month", response.getBody());
    }

    @Test
    public void testHandleAddNewVisitRequest_Exception() throws IOException {
        when(visitorPassRequestsService.addNewVisitRequests(any(MultipartFile.class), any(VisitorPassRequestsDto.class))).thenThrow(new IOException("error"));

        ResponseEntity<?> response = visitorPassController.handleAddNewVisitRequest(file, "employee1", 1, "visit", LocalDate.now(), "location", "visitor", 30, "comingFrom", IdProofType.PASSPORT, "idProofNo");

        assertEquals(HttpStatus.NOT_ACCEPTABLE, response.getStatusCode());
        assertEquals("error", response.getBody());
    }

    @Test
    public void testHandleGetRequestsByEmployeeByPathParam_WithData() {
        List<VisitorPassRequestsDto> dtos = new ArrayList<>();
        dtos.add(new VisitorPassRequestsDto());
        when(visitorPassRequestsService.getRequestsByEmployee("employee1")).thenReturn(dtos);

        ResponseEntity<?> response = visitorPassController.handleGetRequestsByEmployeeByPathParam("employee1");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(dtos, response.getBody());
    }

    @Test
    public void testHandleGetRequestsByEmployeeByPathParam_NoData() {
        when(visitorPassRequestsService.getRequestsByEmployee("employee1")).thenReturn(Collections.emptyList());

        ResponseEntity<?> response = visitorPassController.handleGetRequestsByEmployeeByPathParam("employee1");

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNull(response.getBody());
    }

    @Test
    public void testAuthenticate() {
        UserRequest userRequest = new UserRequest();
        userRequest.setUserName("testUser");
        userRequest.setPassword("testPassword");

        UserDto userDto = new UserDto();
        userDto.setUserName("testUser");
        userDto.setPassword("testPassword");

        when(userService.authenticateUser(userRequest.getUserName(), userRequest.getPassword())).thenReturn(userDto);

        ResponseEntity<?> result = authenticationController.authenticate(userRequest);

        assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());
        assertEquals(userDto, result.getBody());
    }

    @Test
    public void testHandleConstraintViolationException() {
        ConstraintViolationException ex = mock(ConstraintViolationException.class);
        when(ex.getMessage()).thenReturn("Error:Test Constraint Violation");

        ResponseEntity<?> result = visitorPassController.handleConstraintViolationException(ex);

        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        assertEquals("Test Constraint Violation", result.getBody());
    }

}
