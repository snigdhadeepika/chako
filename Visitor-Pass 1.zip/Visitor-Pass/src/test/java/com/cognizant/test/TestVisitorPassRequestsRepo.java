package com.cognizant.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Optional;

import com.cognizant.entities.RequestStatus;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.VisitorPassModuleApplication;
import com.cognizant.entities.VisitorPassRequests;
import com.cognizant.entities.VisitorsIdProofs;
import com.cognizant.repositories.VisitorPassRequestsRepo;

@DataJpaTest
@ContextConfiguration(classes = VisitorPassModuleApplication.class)
class TestVisitorPassRequestsRepo {
	
	@Autowired
	private VisitorPassRequestsRepo visitorPassRequestsRepo;
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void testFindAllPositive() {
		VisitorPassRequests v=new VisitorPassRequests();
		v.setRaisedByEmployee("Sony");
		v.setRequestRaisedOn(LocalDate.now());
		v.setPurposeOfVisit("Client Visit");
		v.setRequestStatus(RequestStatus.APPROVED);
		v.setRequestProcessedByEmployee("Yes");
		v.setRequestProcessedOn(LocalDate.now());
		v.setVisitDate(LocalDate.now());
		v.setCancellationReason("meeting");
		v.setLocation("CDC Pune");
		v.setVisitorName("Chacko");
		v.setVisitorAge(50);
		v.setComingFrom("Kerala");
		entityManager.persist(v);
		Iterable<VisitorPassRequests> it=visitorPassRequestsRepo.findAll();
		assertTrue(it.iterator().hasNext());
	}
	
	@Test
	public void testFindAllNegative() {
		Iterable<VisitorPassRequests> it=visitorPassRequestsRepo.findAll();
		assertTrue(!it.iterator().hasNext());
	}
	
	@Test
	public void testFindByIdPositive() {
		VisitorPassRequests v=new VisitorPassRequests();
		v.setRaisedByEmployee("Sony");
		v.setRequestRaisedOn(LocalDate.now());
		v.setPurposeOfVisit("Client Visit");
		v.setRequestStatus(RequestStatus.APPROVED);
		v.setRequestProcessedByEmployee("Yes");
		v.setRequestProcessedOn(LocalDate.now());
		v.setVisitDate(LocalDate.now());
		v.setCancellationReason("meeting");
		v.setLocation("CDC Pune");
		v.setVisitorName("Chacko");
		v.setVisitorAge(50);
		v.setComingFrom("Kerala");
		entityManager.persist(v);
		Optional<VisitorPassRequests> visitorPassRequests=visitorPassRequestsRepo.findById(v.getId());
		assertTrue(visitorPassRequests.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		VisitorPassRequests v=new VisitorPassRequests();
		Optional<VisitorPassRequests> visitorPassRequests=visitorPassRequestsRepo.findById(v.getId());
		assertTrue(!visitorPassRequests.isPresent());
	}
	
	@Test
	public void testSavePositive() {
		VisitorPassRequests v=new VisitorPassRequests();
		v.setRaisedByEmployee("Sony");
		v.setRequestRaisedOn(LocalDate.now());
		v.setPurposeOfVisit("Client Visit");
		v.setRequestStatus(RequestStatus.APPROVED);
		v.setRequestProcessedByEmployee("Yes");
		v.setRequestProcessedOn(LocalDate.now());
		v.setVisitDate(LocalDate.now());
		v.setCancellationReason("meeting");
		v.setLocation("CDC Pune");
		v.setVisitorName("Chacko");
		v.setVisitorAge(50);
		v.setComingFrom("Kerala");
		visitorPassRequestsRepo.save(v);
		Optional<VisitorPassRequests> visitorPassRequests=visitorPassRequestsRepo.findById(v.getId());
		assertTrue(visitorPassRequests.isPresent());
	}
	
	@Test
	public void testDeletePositive() {
		VisitorPassRequests v=new VisitorPassRequests();
		v.setRaisedByEmployee("Sony");
		v.setRequestRaisedOn(LocalDate.now());
		v.setPurposeOfVisit("Client Visit");
		v.setRequestStatus(RequestStatus.APPROVED);
		v.setRequestProcessedByEmployee("Yes");
		v.setRequestProcessedOn(LocalDate.now());
		v.setVisitDate(LocalDate.now());
		v.setCancellationReason("meeting");
		v.setLocation("CDC Pune");
		v.setVisitorName("Chacko");
		v.setVisitorAge(50);
		v.setComingFrom("Kerala");
		entityManager.persist(v);
		visitorPassRequestsRepo.delete(v);
		Optional<VisitorPassRequests> visitorPassRequests=visitorPassRequestsRepo.findById(v.getId());
		assertTrue(!visitorPassRequests.isPresent());
	}
	
	@Test
	public void testCountPositive() {
		VisitorPassRequests v=new VisitorPassRequests();
		v.setRaisedByEmployee("Sony");
		v.setRequestRaisedOn(LocalDate.now());
		v.setPurposeOfVisit("Client Visit");
		v.setRequestStatus(RequestStatus.APPROVED);
		v.setRequestProcessedByEmployee("Yes");
		v.setRequestProcessedOn(LocalDate.now());
		v.setVisitDate(LocalDate.now());
		v.setCancellationReason("meeting");
		v.setLocation("CDC Pune");
		v.setVisitorName("Chacko");
		v.setVisitorAge(50);
		v.setComingFrom("Kerala");
		entityManager.persist(v);
		long expectedCount=1;
		long actualCount=visitorPassRequestsRepo.count();
		assertEquals(expectedCount, actualCount);
	}
}
