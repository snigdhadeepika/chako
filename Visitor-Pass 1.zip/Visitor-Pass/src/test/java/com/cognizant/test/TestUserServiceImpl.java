package com.cognizant.test;

import com.cognizant.dto.UserDto;
import com.cognizant.entities.Users;
import com.cognizant.repositories.UserRepo;
import com.cognizant.service.UserService;
import com.cognizant.service.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class TestUserServiceImpl {
    @Mock
    UserRepo userRepo;
    @InjectMocks
    UserServiceImpl userServiceImpl;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testListOfUsers() {
        Users user1 = new Users();
        user1.setUserName("John");
        Users user2 = new Users();
        user2.setUserName("Jane");
        List<Users> expectedUsers = Arrays.asList(user1, user2);
        when(userRepo.findAll()).thenReturn(expectedUsers);
        List<Users> actualUsers = userServiceImpl.listOfUsers();
        assertEquals(expectedUsers, actualUsers);
    }

    @Test
    public void testAuthenticateUser() {
        String username = "testUser";
        String password = "testPassword";
        String role = "testRole";
        String employeeId = "testEmployeeId";
        boolean accountLocked = false;

        Users testUser = new Users();
        testUser.setUserName(username);
        testUser.setPassword(password);
        testUser.setRole(role);
        testUser.setEmployeeId(employeeId);
        testUser.setAccountLocked(accountLocked);

        when(userRepo.findAll()).thenReturn(Arrays.asList(testUser));
        UserDto result = userServiceImpl.authenticateUser(username, password);
        assertEquals(username, result.getUserName());
        assertEquals(password, result.getPassword());
        assertEquals(role, result.getRole());
        assertEquals(employeeId, result.getEmployeeId());
        assertEquals(accountLocked, result.isAccountLocked());
    }
}
