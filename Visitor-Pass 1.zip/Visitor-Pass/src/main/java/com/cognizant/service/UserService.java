package com.cognizant.service;

import com.cognizant.dto.UserDto;
import com.cognizant.entities.Users;

import java.util.List;

public interface UserService {
    public List<Users> listOfUsers();
    public UserDto authenticateUser(String username, String password);
}
