package com.cognizant.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.VisitorTypesDto;
import com.cognizant.entities.VisitorTypes;
import com.cognizant.repositories.VisitorTypesRepo;

@Service
public class VisitorTypesServiceImpl implements VisitorTypesService {

	@Autowired
	VisitorTypesRepo visitorTypesRepo;
	
	@Override
	public List<VisitorTypesDto> getAllVisitorTypes() {
		List<VisitorTypes> visitorTypes=visitorTypesRepo.findAll();
		List<VisitorTypesDto> dtos=new ArrayList<VisitorTypesDto>();
		for(VisitorTypes v:visitorTypes) {
			VisitorTypesDto dto = new VisitorTypesDto();
			dto.setId(v.getId());
			dto.setType(v.getType());
			dtos.add(dto);
		}
		if(dtos.isEmpty()){
			throw new RuntimeException("List is Empty");
		}
		return dtos;
	}
}
	