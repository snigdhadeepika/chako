package com.cognizant.service;

import com.cognizant.dto.UserDto;
import com.cognizant.entities.Users;
import com.cognizant.repositories.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserRepo userRepo;
    @Override
    public List<Users> listOfUsers() {
        return (List<Users>) userRepo.findAll();
    }

    @Override
    public UserDto authenticateUser(String username, String password) {
        List<Users> users= listOfUsers();
        UserDto userModel=new UserDto();
        for(Users user:users) {
            if(user.getUserName().equals(username) && user.getPassword().equals(password) && !user.isAccountLocked()) {
                userModel.setUserName(user.getUserName());
                userModel.setPassword(user.getPassword());
                userModel.setRole(user.getRole());
                userModel.setEmployeeId(user.getEmployeeId());
                userModel.setAccountLocked(user.isAccountLocked());
                break;
            }
        }
        return userModel;
    }
}
