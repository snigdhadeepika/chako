package com.cognizant.service;

import java.util.List;

import com.cognizant.dto.VisitorTypesDto;

public interface VisitorTypesService {
	List<VisitorTypesDto> getAllVisitorTypes();
}
