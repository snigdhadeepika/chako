package com.cognizant.service;

import java.io.IOException;
import java.util.List;

import com.cognizant.dto.UpdatePassRequestDto;
import com.cognizant.dto.VisitorPassRequestsDto;
import com.cognizant.entities.VisitorPassRequests;
import org.springframework.web.multipart.MultipartFile;

public interface VisitorPassRequestsService {
	String addNewVisitRequests(MultipartFile file, VisitorPassRequestsDto visitorPassRequestsDto) throws IOException;
	String approveRejectRequest(UpdatePassRequestDto updatePassRequestDto);
	VisitorPassRequestsDto getRequestById(int id);
	List<VisitorPassRequestsDto> getPendingRequestByLocation(String location);
	List<VisitorPassRequestsDto> getRequestsByEmployee(String raisedByEmployee);

	
}
