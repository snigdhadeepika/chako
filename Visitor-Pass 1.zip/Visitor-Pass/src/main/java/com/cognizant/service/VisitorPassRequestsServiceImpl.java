package com.cognizant.service;

import java.io.File;
import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.*;

import com.cognizant.dto.VisitorsIdProofsDto;
import com.cognizant.entities.RequestStatus;
import com.cognizant.exception.MaximumPassRequestLimitReachedException;
import com.cognizant.repositories.VisitorTypesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.UpdatePassRequestDto;
import com.cognizant.dto.VisitorPassRequestsDto;
import com.cognizant.entities.VisitorPassRequests;
import com.cognizant.entities.VisitorTypes;
import com.cognizant.entities.VisitorsIdProofs;
import com.cognizant.repositories.VisitorIdProofsRepo;
import com.cognizant.repositories.VisitorPassRequestsRepo;
import org.springframework.web.multipart.MultipartFile;

@Service
public class VisitorPassRequestsServiceImpl implements VisitorPassRequestsService {

	@Autowired
	private VisitorIdProofsRepo visitorIdProofsRepo;
	@Autowired
	private VisitorPassRequestsRepo visitorPassRequestsRepo;
	@Autowired
	private VisitorTypesRepo visitorTypesRepo;

	private final String FOLDER_PATH="C:\\Users\\2317167\\OneDrive - Cognizant\\Desktop\\Files";


	@Override
	public String addNewVisitRequests(MultipartFile file, VisitorPassRequestsDto visitorPassRequestsDto)throws IOException {
		int passRequestCount= submitRequest(visitorPassRequestsDto.getRaisedByEmployee());
		int maxLimit=5;
		if (passRequestCount>=maxLimit){
			throw new MaximumPassRequestLimitReachedException("Maximum pass request limit reached for " + visitorPassRequestsDto.getRaisedByEmployee());
		}

		VisitorPassRequests visitorPassRequests = new VisitorPassRequests();
		Optional<VisitorTypes> visitorTypes = visitorTypesRepo.findById(visitorPassRequestsDto.getVisitorTypeId());
		VisitorTypes types = null;
		if(visitorTypes.isPresent()){
			types = visitorTypes.get();
		}
		VisitorPassRequests requestCreated = null;
		VisitorsIdProofs idCreated= null;

		LocalDate today= LocalDate.now();
		LocalDate visitDate= visitorPassRequestsDto.getVisitDate();
		if(visitDate.isBefore(today.plusWeeks(1))){
			throw new IllegalArgumentException("Visit Date must be atleast one week in advance");
		}


		DayOfWeek dayOfWeek = visitorPassRequestsDto.getVisitDate().getDayOfWeek();
		boolean isWeekend = dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY;

		if(!types.getType().equalsIgnoreCase("Client")) {
			if (canRaiseFamilyVisitorRequest(visitorPassRequestsDto.getRaisedByEmployee()) && isWeekend) {
				raiseFamilyVisitorRequest(visitorPassRequestsDto.getRaisedByEmployee());
				visitorPassRequests.setRaisedByEmployee(visitorPassRequestsDto.getRaisedByEmployee());
				visitorPassRequests.setRequestRaisedOn(LocalDate.now());
				visitorPassRequests.setPurposeOfVisit(visitorPassRequestsDto.getPurposeOfVisit());
				visitorPassRequests.setRequestStatus(RequestStatus.PENDING);
				visitorPassRequests.setRequestProcessedByEmployee(visitorPassRequestsDto.getRequestProcessedByEmployee());
				visitorPassRequests.setRequestProcessedOn(visitorPassRequestsDto.getRequestProcessedOn());
				visitorPassRequests.setVisitDate(visitorPassRequestsDto.getVisitDate());
				visitorPassRequests.setCancellationReason(visitorPassRequestsDto.getCancellationReason());
				visitorPassRequests.setLocation(visitorPassRequestsDto.getLocation());
				visitorPassRequests.setVisitorName(visitorPassRequestsDto.getVisitorName());
				visitorPassRequests.setVisitorAge(visitorPassRequestsDto.getVisitorAge());
				visitorPassRequests.setComingFrom(visitorPassRequestsDto.getComingFrom());
				visitorPassRequests.setVisitorTypes(types);
				requestCreated = visitorPassRequestsRepo.save(visitorPassRequests);

				VisitorsIdProofs visitorsIdProofs = new VisitorsIdProofs();
				String filePath = FOLDER_PATH;
				visitorsIdProofs.setIdProofType(visitorPassRequestsDto.getIdProofType());
				visitorsIdProofs.setIdProofNo(visitorPassRequestsDto.getIdProofNo());
				visitorsIdProofs.setIdProofUrl(filePath);
				visitorsIdProofs.setVisitorPassRequests(requestCreated);

				String originalFileName = file.getOriginalFilename();
				String extension = originalFileName.substring(originalFileName.lastIndexOf("."));
				String newFileName = visitorsIdProofs.getIdProofNo() + extension;

				file.transferTo(new File(filePath+"\\"+ newFileName));
				idCreated = visitorIdProofsRepo.save(visitorsIdProofs);
				incrementRequestCount(visitorPassRequestsDto.getRaisedByEmployee());

			} else if (!isWeekend) {
				throw new IllegalArgumentException("Visit requests for family members can only be raised for the weekend");
			}
		}
		else{
			visitorPassRequests.setRaisedByEmployee(visitorPassRequestsDto.getRaisedByEmployee());
			visitorPassRequests.setRequestRaisedOn(LocalDate.now());
			visitorPassRequests.setPurposeOfVisit(visitorPassRequestsDto.getPurposeOfVisit());
			visitorPassRequests.setRequestStatus(RequestStatus.PENDING);
			visitorPassRequests.setRequestProcessedByEmployee(visitorPassRequestsDto.getRequestProcessedByEmployee());
			visitorPassRequests.setRequestProcessedOn(visitorPassRequestsDto.getRequestProcessedOn());
			visitorPassRequests.setVisitDate(visitorPassRequestsDto.getVisitDate());
			visitorPassRequests.setCancellationReason(visitorPassRequestsDto.getCancellationReason());
			visitorPassRequests.setLocation(visitorPassRequestsDto.getLocation());
			visitorPassRequests.setVisitorName(visitorPassRequestsDto.getVisitorName());
			visitorPassRequests.setVisitorAge(visitorPassRequestsDto.getVisitorAge());
			visitorPassRequests.setComingFrom(visitorPassRequestsDto.getComingFrom());
			visitorPassRequests.setVisitorTypes(types);
			requestCreated = visitorPassRequestsRepo.save(visitorPassRequests);

			VisitorsIdProofs visitorsIdProofs = new VisitorsIdProofs();
			String filePath= FOLDER_PATH;

			visitorsIdProofs.setIdProofType(visitorPassRequestsDto.getIdProofType());
			visitorsIdProofs.setIdProofNo(visitorPassRequestsDto.getIdProofNo());
			visitorsIdProofs.setIdProofUrl(filePath);
			visitorsIdProofs.setVisitorPassRequests(requestCreated);

			String originalFileName = file.getOriginalFilename();
			String extension = originalFileName.substring(originalFileName.lastIndexOf("."));
			String newFileName = visitorsIdProofs.getIdProofNo() + extension;

			file.transferTo(new File(filePath+"\\"+ newFileName));
			idCreated= visitorIdProofsRepo.save(visitorsIdProofs);
			incrementRequestCount(visitorPassRequestsDto.getRaisedByEmployee());

		}

		if (requestCreated != null && idCreated != null) {
			return "success";
		} else {
			return "fail";
		}
	}
	private Map<String,Integer> familyRequestCountMap= new HashMap<>();
	public boolean canRaiseFamilyVisitorRequest(String raisedByEmployee){
		LocalDate currentDate= LocalDate.now();
		int currentMonth= currentDate.getMonthValue();
		int currentYear= currentDate.getYear();

		String key= raisedByEmployee + "-family-" + currentMonth + "-" + currentYear;
		int familyRequestCount= familyRequestCountMap.getOrDefault(key,0);
		return familyRequestCount < 2;
	}
	public void raiseFamilyVisitorRequest(String raisedByEmployee){
		LocalDate currentDate= LocalDate.now();
		int currentMonth= currentDate.getMonthValue();
		int currentYear= currentDate.getYear();

		String key= raisedByEmployee + "-family-" + currentMonth + "-" + currentYear;
		int familyRequestCount= familyRequestCountMap.getOrDefault(key,0);
		familyRequestCountMap.put(key,familyRequestCount+1);

	}

	private Map<String,Integer> userRequestCountMap= new HashMap<>();
	public int submitRequest(String raisedByEmployee) {
		LocalDate currentDate= LocalDate.now();
		int currentMonth= currentDate.getMonthValue();
		int currentYear= currentDate.getYear();
		String key= raisedByEmployee + "-" + currentMonth + "-" + currentYear;
		int requestCount= userRequestCountMap.getOrDefault(key,0);
		return requestCount;
	}
	public void incrementRequestCount(String raisedByEmployee) {
		LocalDate currentDate= LocalDate.now();
		int currentMonth= currentDate.getMonthValue();
		int currentYear= currentDate.getYear();
		String key= raisedByEmployee + "-" + currentMonth + "-" + currentYear;
		int requestCount= userRequestCountMap.getOrDefault(key,0);
		userRequestCountMap.put(key,requestCount+1);
	}
	@Override
	public String approveRejectRequest(UpdatePassRequestDto updatePassRequestDto) {
		Optional<VisitorPassRequests> visitorPassRequests = visitorPassRequestsRepo
				.findById(updatePassRequestDto.getId());
		VisitorPassRequests requestUpdated = null;
		if (visitorPassRequests.isPresent()) {
			VisitorPassRequests request = visitorPassRequests.get();
			request.setRequestStatus(updatePassRequestDto.getRequestStatus());
			request.setCancellationReason(updatePassRequestDto.getCancellationReason());
			requestUpdated = visitorPassRequestsRepo.save(request);

		}
		if (requestUpdated != null)
			return "success";
		else
			return "fail";
	}

	@Override
	public VisitorPassRequestsDto getRequestById(int id) {
		Optional<VisitorPassRequests> visitorPassRequests = visitorPassRequestsRepo.findById(id);
		VisitorPassRequestsDto dtos = new VisitorPassRequestsDto();
		if (visitorPassRequests.isPresent()) {
			VisitorPassRequests request = visitorPassRequests.get();
			dtos.setId(request.getId());
			dtos.setRaisedByEmployee(request.getRaisedByEmployee());
			dtos.setRequestRaisedOn(request.getRequestRaisedOn());
			dtos.setVisitorTypeId(request.getVisitorTypes().getId());
			dtos.setPurposeOfVisit(request.getPurposeOfVisit());
			dtos.setRequestStatus(request.getRequestStatus());
			dtos.setRequestProcessedByEmployee(request.getRequestProcessedByEmployee());
			dtos.setRequestProcessedOn(request.getRequestProcessedOn());
			dtos.setVisitDate(request.getVisitDate());
			dtos.setCancellationReason(request.getCancellationReason());
			dtos.setLocation(request.getLocation());
			dtos.setVisitorName(request.getVisitorName());
			dtos.setVisitorAge(request.getVisitorAge());
			dtos.setComingFrom(request.getComingFrom());

			Optional<VisitorsIdProofs> visitorsIdProofs= visitorIdProofsRepo.findById(request.getId());
			VisitorsIdProofs idProofs= visitorsIdProofs.get();
			dtos.setIdProofNo(idProofs.getIdProofNo());
			dtos.setIdProofType(idProofs.getIdProofType());
			dtos.setIdProofUrl(idProofs.getIdProofUrl());

		}
		return dtos;
	}

	@Override
	public List<VisitorPassRequestsDto> getPendingRequestByLocation(String location) {
		List<VisitorPassRequests> visitorPassRequests = visitorPassRequestsRepo.findByLocation(location);
		List<VisitorPassRequestsDto> dtos = new ArrayList<>();
		for (VisitorPassRequests v : visitorPassRequests) {
			if(v.getRequestStatus().equals(RequestStatus.PENDING)){
				VisitorPassRequestsDto dto = new VisitorPassRequestsDto();
				VisitorTypes visitorTypes = new VisitorTypes();
				dto.setId(v.getId());
				dto.setRaisedByEmployee(v.getRaisedByEmployee());
				dto.setRequestRaisedOn(v.getRequestRaisedOn());
				dto.setVisitorTypeId(v.getVisitorTypes().getId());
				dto.setPurposeOfVisit(v.getPurposeOfVisit());
				dto.setRequestStatus(v.getRequestStatus());
				dto.setRequestProcessedByEmployee(v.getRequestProcessedByEmployee());
				dto.setRequestProcessedOn(v.getRequestProcessedOn());
				dto.setVisitDate(v.getVisitDate());
				dto.setCancellationReason(v.getCancellationReason());
				dto.setLocation(v.getLocation());
				dto.setVisitorName(v.getVisitorName());
				dto.setVisitorAge(v.getVisitorAge());
				dto.setComingFrom(v.getComingFrom());

				Optional<VisitorsIdProofs> visitorsIdProofs= visitorIdProofsRepo.findById(v.getId());
				VisitorsIdProofs idProofs= visitorsIdProofs.get();
				dto.setIdProofType(idProofs.getIdProofType());
				dto.setIdProofNo(idProofs.getIdProofNo());
				dto.setIdProofUrl(idProofs.getIdProofUrl());
				dtos.add(dto);
			}
		}
		return dtos;
	}

	@Override
	public List<VisitorPassRequestsDto> getRequestsByEmployee(String raisedByEmployee) {
		List<VisitorPassRequests> visitorPassRequests = visitorPassRequestsRepo.findByRaisedByEmployee(raisedByEmployee);
		List<VisitorPassRequestsDto> dtos = new ArrayList<>();
		for (VisitorPassRequests v : visitorPassRequests) {
			VisitorPassRequestsDto dto = new VisitorPassRequestsDto();
			dto.setId(v.getId());
			dto.setRaisedByEmployee(v.getRaisedByEmployee());
			dto.setRequestRaisedOn(v.getRequestRaisedOn());
			dto.setVisitorTypeId(v.getVisitorTypes().getId());
			dto.setPurposeOfVisit(v.getPurposeOfVisit());
			dto.setRequestStatus(v.getRequestStatus());
			dto.setRequestProcessedByEmployee(v.getRequestProcessedByEmployee());
			dto.setRequestProcessedOn(v.getRequestProcessedOn());
			dto.setVisitDate(v.getVisitDate());
			dto.setCancellationReason(v.getCancellationReason());
			dto.setLocation(v.getLocation());
			dto.setVisitorName(v.getVisitorName());
			dto.setVisitorAge(v.getVisitorAge());
			dto.setComingFrom(v.getComingFrom());
			Optional<VisitorsIdProofs> visitorsIdProofs= visitorIdProofsRepo.findById(v.getId());
			VisitorsIdProofs idProofs= visitorsIdProofs.get();
			dto.setIdProofType(idProofs.getIdProofType());
			dto.setIdProofNo(idProofs.getIdProofNo());
			dto.setIdProofUrl(idProofs.getIdProofUrl());
			dtos.add(dto);
		}
		return dtos;
	}

}
