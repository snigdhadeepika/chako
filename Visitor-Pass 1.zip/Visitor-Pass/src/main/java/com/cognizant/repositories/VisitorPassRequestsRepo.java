package com.cognizant.repositories;

import com.cognizant.entities.VisitorPassRequests;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VisitorPassRequestsRepo extends JpaRepository<VisitorPassRequests, Integer> {
	List<VisitorPassRequests> findByLocation(String location);
	List<VisitorPassRequests> findByRaisedByEmployee(String raisedByEmployee);
}
