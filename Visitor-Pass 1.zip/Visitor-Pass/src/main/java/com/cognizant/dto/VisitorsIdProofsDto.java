package com.cognizant.dto;

import com.cognizant.entities.IdProofType;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VisitorsIdProofsDto {
	private int requestId;
	private IdProofType idProofType;
	private String idProofNo;
	private String idProofUrl;

}
