package com.cognizant.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VisitorTypesDto {
	private int id;
	private String type;

}
