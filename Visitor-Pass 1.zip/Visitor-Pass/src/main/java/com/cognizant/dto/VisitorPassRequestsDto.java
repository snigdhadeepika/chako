package com.cognizant.dto;

import java.time.LocalDate;

import com.cognizant.entities.IdProofType;
import com.cognizant.entities.RequestStatus;
import com.cognizant.entities.VisitorTypes;
import com.cognizant.entities.VisitorsIdProofs;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

@Data
@NoArgsConstructor
public class VisitorPassRequestsDto {
	private int id;
	@NotBlank(message = "{com.cognizant.dto.VisitorPassRequestsDto.raisedByEmployee.error}")
	private String raisedByEmployee;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate requestRaisedOn;
	private int visitorTypeId;
	@NotBlank(message = "{com.cognizant.dto.VisitorPassRequestsDto.purposeOfVisit.error}")
	private String purposeOfVisit;
	private RequestStatus requestStatus;
	private String requestProcessedByEmployee;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate requestProcessedOn;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate visitDate;
	private String cancellationReason;
	@NotBlank(message = "{com.cognizant.dto.VisitorPassRequestsDto.location.error}")
	private String location;
	@NotBlank(message = "{com.cognizant.dto.VisitorPassRequestsDto.visitorName.error}")
	private String visitorName;
	@Positive(message = "{com.cognizant.dto.VisitorPassRequestsDto.visitorAge.error}")
	private int visitorAge;
	@NotBlank(message = "{com.cognizant.dto.VisitorPassRequestsDto.comingFrom.error}")
	private String comingFrom;
	private IdProofType idProofType;
	private String idProofNo;
	private String idProofUrl;
}
