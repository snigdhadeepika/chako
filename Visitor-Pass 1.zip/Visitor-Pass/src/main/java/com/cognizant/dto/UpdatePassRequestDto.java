package com.cognizant.dto;

import com.cognizant.entities.RequestStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UpdatePassRequestDto {
	@NotNull
	private int id;
	@NotBlank
	private RequestStatus requestStatus;
	private String cancellationReason;

}
