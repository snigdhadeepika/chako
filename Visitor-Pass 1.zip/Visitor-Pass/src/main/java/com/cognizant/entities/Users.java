package com.cognizant.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Entity
@Table(name="Users")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Users {
    @Id
    @Column(name="user_name")
    private String userName;
    @Column(name="password")
    private String password;
    @Column(name="role")
    private String role;
    @Column(name="employee_id")
    private String employeeId;
    @Column(name="is_Account_Locked")
    private boolean isAccountLocked;

    @Override
    public int hashCode() {
        return Objects.hash(isAccountLocked, password, role, userName);
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Users other = (Users) obj;
        return isAccountLocked == other.isAccountLocked && Objects.equals(password, other.password)
                && Objects.equals(role, other.role) && Objects.equals(userName, other.userName);
    }
    @Override
    public String toString() {
        return "Users [userName=" + userName + ", password=" + password + ", role=" + role + ", isAccountLocked="
                + isAccountLocked + "]";
    }

}
