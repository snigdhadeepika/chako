package com.cognizant.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name = "Visitor_Types")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VisitorTypes {
	@Id
	@Column(name = "Id")
	private int id;
	@Column(name = "Type")
	private String type;

	@OneToMany(mappedBy = "visitorTypes", cascade = CascadeType.ALL)
	private List<VisitorPassRequests> visitorPassRequests;

}
