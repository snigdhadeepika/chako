package com.cognizant.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum IdProofType {
    AADHAR("AADHAR"),
    VOTERID("VOTERID"),
    PASSPORT("PASSPORT");

    private final String value;

}
