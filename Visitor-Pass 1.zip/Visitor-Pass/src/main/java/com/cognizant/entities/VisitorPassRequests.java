package com.cognizant.entities;

import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Visitor_Pass_Requests")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VisitorPassRequests {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_SEQ")
	@SequenceGenerator(sequenceName = "ID_SEQ", name = "ID_SEQ", allocationSize = 1)
	@Column(name = "Id")
	private int id;
	@Column(name = "Raised_By_Employee")
	private String raisedByEmployee;
	@Column(name = "Request_Raised_On")
	private LocalDate requestRaisedOn;
	@Column(name = "Purpose_Of_Visit")
	private String purposeOfVisit;
	@Column(name = "Request_Status")
	@Enumerated(EnumType.STRING)
	private RequestStatus requestStatus;
	@Column(name = "Request_Processed_By_Employee")
	private String requestProcessedByEmployee;
	@Column(name = "Request_Processed_On")
	private LocalDate requestProcessedOn;
	@Column(name = "Visit_Date")
	private LocalDate visitDate;
	@Column(name = "Cancellation_Reason")
	private String cancellationReason;
	@Column(name = "Location")
	private String location;
	@Column(name = "Visitor_Name")
	private String visitorName;
	@Column(name = "Visitor_Age")
	private int visitorAge;
	@Column(name = "Coming_From")
	private String comingFrom;

	@OneToOne(mappedBy = "visitorPassRequests", cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private VisitorsIdProofs visitorsIdProofs;

	@ManyToOne
	@JoinColumn(name = "Visitor_Type_Id")
	private VisitorTypes visitorTypes;

}
