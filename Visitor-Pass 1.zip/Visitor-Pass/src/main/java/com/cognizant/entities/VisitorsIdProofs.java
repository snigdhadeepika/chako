package com.cognizant.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Visitors_Id_Proofs")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VisitorsIdProofs {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_SEQ_REQUEST")
	@SequenceGenerator(sequenceName = "ID_SEQ_REQUEST", name = "ID_SEQ_REQUEST", allocationSize = 1)
	@Column(name = "Request_Id")
	private int requestId;
	@Column(name = "Id_Proof_Type")
	@Enumerated(EnumType.STRING)
	private IdProofType idProofType;
	@Column(name = "Id_Proof_No")
	private String idProofNo;
	@Column(name = "Id_Proof_Url")
	private String idProofUrl;

	@OneToOne
	private VisitorPassRequests visitorPassRequests;

}
