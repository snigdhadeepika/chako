package com.cognizant.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import com.cognizant.entities.IdProofType;
import com.cognizant.exception.MaximumPassRequestLimitReachedException;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.*;
import org.springframework.context.support.DefaultMessageSourceResolvable;

import com.cognizant.dto.UpdatePassRequestDto;
import com.cognizant.dto.VisitorPassRequestsDto;
import com.cognizant.dto.VisitorTypesDto;
import com.cognizant.service.VisitorPassRequestsService;
import com.cognizant.service.VisitorTypesService;
import org.springframework.web.multipart.MultipartFile;


@RestController
@Slf4j
@RequestMapping("api")
@Validated
@CrossOrigin(origins = "http://localhost:4200")
public class VisitorPassController {
	@Autowired
	private VisitorTypesService visitorTypesService;
	@Autowired
	VisitorPassRequestsService visitorPassRequestsService;

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handleValidationExceptions(MethodArgumentNotValidException ex) {
		BindingResult bindingResult = ex.getBindingResult();
		List<String> errorMessages = bindingResult.getAllErrors().stream()
				.map(DefaultMessageSourceResolvable::getDefaultMessage)
				.collect(Collectors.toList());
		return new ResponseEntity<>(errorMessages, HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public ResponseEntity<String> handleMissingParams(MissingServletRequestParameterException ex) {
		String name = ex.getParameterName();
		return new ResponseEntity<>("'" + name + "' parameter is missing", HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<?> handleConstraintViolationException(ConstraintViolationException ex) {
       System.out.println("Message:"+ex.getMessage());
		StringTokenizer stringTokenizer=new StringTokenizer(ex.getMessage(),":");
		List<String> errorMessage=new ArrayList<>();
		while(stringTokenizer.hasMoreTokens()){
			errorMessage.add(stringTokenizer.nextToken());
		}
		return new ResponseEntity<>(errorMessage.get(1), HttpStatus.BAD_REQUEST);
	}

	@Operation(description = "getting types")
	@GetMapping("visitortypes")
	public ResponseEntity<?> handleGetAllVisitorTypes() {
		List<VisitorTypesDto> dto = visitorTypesService.getAllVisitorTypes();
		ResponseEntity<List<VisitorTypesDto>> responseEntity = null;
		if (!dto.isEmpty()) {
			responseEntity = new ResponseEntity<List<VisitorTypesDto>>(dto, HttpStatus.OK);
			log.info("Successfully retrieved visitor types");
		} else {
			responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}

	@PostMapping(value = "passrequests/new",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<?> handleAddNewVisitRequest(@RequestParam("file") MultipartFile file, @RequestParam("raisedByEmployee") @NotBlank(message = "Raised by Employee cannot be blank") String raisedByEmployee, @RequestParam("visitorTypeId") int visitorTypeId, @RequestParam("purposeOfVisit") @NotBlank(message = "Purpose of visit cannot be blank")String purposeOfVisit, @RequestParam("visitDate") LocalDate visitDate, @RequestParam("location") @NotBlank(message = "Location cannot be blank") String location, @RequestParam("visitorName") @NotBlank(message = "Visitor name cannot be blank") String visitorName, @RequestParam("visitorAge") @Min(value = 1, message = "Invalid age") int visitorAge, @RequestParam("comingFrom") @NotBlank(message = "Coming from cannot be blank")String comingFrom, @RequestParam("idProofType") IdProofType idProofType, @RequestParam("idProofNo") String idProofNo ) {
		VisitorPassRequestsDto visitorPassRequestsDto =new VisitorPassRequestsDto();
		visitorPassRequestsDto.setRaisedByEmployee(raisedByEmployee);
		visitorPassRequestsDto.setVisitorTypeId(visitorTypeId);
		visitorPassRequestsDto.setPurposeOfVisit(purposeOfVisit);
		visitorPassRequestsDto.setVisitDate(visitDate);
		visitorPassRequestsDto.setLocation(location);
		visitorPassRequestsDto.setVisitorName(visitorName);
		visitorPassRequestsDto.setVisitorAge(visitorAge);
		visitorPassRequestsDto.setComingFrom(comingFrom);
		visitorPassRequestsDto.setIdProofType(idProofType);
		visitorPassRequestsDto.setIdProofNo(idProofNo);
		System.out.println(visitorPassRequestsDto);
		try {
			String result = visitorPassRequestsService.addNewVisitRequests(file, visitorPassRequestsDto);
			log.info("Add new request is called");
			if (result.equals("success")) {
				return new ResponseEntity<>("Request is generated", HttpStatus.OK);
			} else {
				return new ResponseEntity<>("User can only add two request for family members in a month", HttpStatus.BAD_REQUEST);
			}
		}
		catch(MaximumPassRequestLimitReachedException e){
			return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_ACCEPTABLE);
		}
		catch(IllegalArgumentException e){
			return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_ACCEPTABLE);
		} catch (IOException e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_ACCEPTABLE);
        }
    }

	@GetMapping("passrequests/{id}")
	public ResponseEntity<?> handleGetRequestByIdByPathParam(@PathVariable("id") int id) {
		VisitorPassRequestsDto dto = visitorPassRequestsService.getRequestById(id);
		log.info("Get request by id is called");
		ResponseEntity<VisitorPassRequestsDto> responseEntity = null;
		if (dto.getId() != 0) {
			responseEntity = new ResponseEntity<VisitorPassRequestsDto>(dto, HttpStatus.OK);
		} else {
			responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}

	@GetMapping("passrequests/location/{location}")
	public ResponseEntity<?> handleGetPendingRequestByLocationByPathParam(@PathVariable("location") String location) {
		List<VisitorPassRequestsDto> dto = visitorPassRequestsService.getPendingRequestByLocation(location);
		log.info("Get Pending Request is called");
		ResponseEntity<List<VisitorPassRequestsDto>> responseEntity = null;
		if (!dto.isEmpty()) {
			responseEntity = new ResponseEntity<List<VisitorPassRequestsDto>>(dto, HttpStatus.OK);
		} else {
			responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}

	@GetMapping("passrequests/employee/{raisedByEmployee}")
	public ResponseEntity<?> handleGetRequestsByEmployeeByPathParam(@PathVariable("raisedByEmployee") String raisedByEmployee) {
		List<VisitorPassRequestsDto> dto = visitorPassRequestsService.getRequestsByEmployee(raisedByEmployee);
		log.info("Get request by employee is called");
		ResponseEntity<List<VisitorPassRequestsDto>> responseEntity = null;
		if (!dto.isEmpty()) {
			responseEntity = new ResponseEntity<List<VisitorPassRequestsDto>>(dto, HttpStatus.OK);
		} else {
			responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}

	@PostMapping("passrequests/approvereject")
	public ResponseEntity<?> handleApproveRejectRequest(@RequestBody UpdatePassRequestDto updatePassRequestDto) {
		String result = visitorPassRequestsService.approveRejectRequest(updatePassRequestDto);
		log.info("Approve Reject is called");
		if (result.equals("success")) {
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

	}


}
