package com.cognizant.exception;

public class MaximumPassRequestLimitReachedException extends RuntimeException {
    public MaximumPassRequestLimitReachedException(String message){
        super(message);
    }
}
