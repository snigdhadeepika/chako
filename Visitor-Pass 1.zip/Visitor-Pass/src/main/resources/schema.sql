CREATE TABLE Visitor_Types(
Id int,
Type varchar(10),
CONSTRAINT PK_VisitorTypes PRIMARY KEY(Id)
);

CREATE TABLE Visitor_Pass_Requests(
Id int,
Raised_By_Employee varchar(6),
Request_Raised_On date,
Visitor_Type_Id int,
Purpose_Of_Visit varchar(50),
Request_Status varchar(10),
Request_Processed_By_Employee varchar(6),
Request_Processed_On date,
Visit_Date date,
Cancellation_Reason varchar(100),
Location varchar(20),
Visitor_Name varchar(30),
Visitor_Age int,
Coming_From varchar(20),
CONSTRAINT PK_VisitorPassRequests PRIMARY KEY(Id),
CONSTRAINT FK_VisitorTypes_VisitorPassRequests FOREIGN KEY(Visitor_Type_Id) REFERENCES Visitor_Types(Id)
);

CREATE TABLE Visitors_Id_Proofs(
Request_Id int,
Id_Proof_Type varchar(10),
Id_Proof_No varchar(20),
Id_Proof_Url varchar(100),
CONSTRAINT PK_VisitorsIdProofs PRIMARY KEY(Request_Id)
);

create table Users(
user_name varchar(40),
password varchar(40) not null,
role varchar(40) not null,
employee_id varchar(40),
is_Account_Locked boolean
);

CREATE SEQUENCE "ID_SEQ"
MINVALUE 1
MAXVALUE 999999999
INCREMENT BY 1
START WITH 1
NOCACHE
NOCYCLE;
CREATE SEQUENCE "ID_SEQ_REQUEST"
MINVALUE 1
MAXVALUE 999999999
INCREMENT BY 1
START WITH 1
NOCACHE
NOCYCLE;