INSERT INTO Visitor_Types VALUES
(1,'Parents'),
(2,'Child'),
(3,'Sibling'),
(4,'Spouse'),
(5,'Client');

insert into Users values('sony','sony123','employee','100',false);
insert into users values('antony','antony123','security','200',false);